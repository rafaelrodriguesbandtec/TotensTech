package com.mycompany.projeto.pi;

import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.hardware.HardwareAbstractionLayer;
//import oshi.software.os.NetworkParams;

public class MostrarTudo {
   
    SystemInfo systemInfo = new SystemInfo();
    //Informações sobre o sistema
        
        HardwareAbstractionLayer hardwareInfo = systemInfo.getHardware();
        //Inforções sobre os componentes
        
        CentralProcessor cpu = hardwareInfo.getProcessor();
        //Informações da CPU
        
        GlobalMemory GM = hardwareInfo.getMemory();
        //Informações da memória
       
        //NetworkParams net = systemInfo.getOperatingSystem().getNetworkParams();
        //Informações placa de rede e sistema (Ip etc)
       
        
        private String memoriaDisponivel = "", memoriaTotal = "", memoriaFisica = "";


    
        public void verificarMemoriaDisponivel(){
        memoriaDisponivel = String.format("Memória disponivel: %.2f", Double.valueOf(GM.getAvailable()));    
        
        //memoriaTotal = String.format("Memória total: %.2f", Double.valueOf(GM.getTotal()));    
        
        //memoriaFisica = String.format("Memória fisica: %.2f", Double.valueOf(GM.getPhysicalMemory()));          
        }

    public String getMemoriaTotal() {
        return memoriaTotal;
    }

    public String getMemoriaFisica() {
        return memoriaFisica;
    }
        
        public String getMemoriaDisponivel() {
            return memoriaDisponivel;   
        }
  
    }


